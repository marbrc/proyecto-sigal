package mx.utng.controller;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.layout.VBox;
import mx.utng.dao.UsuarioDAO;
import mx.utng.model.Usuario;
import mx.utng.util.AvatarUtil;
import mx.utng.util.ThemeManager;

/**
 * Controlador de la pantalla "Ajustes" (fx_ajustes.fxml).
 *
 * El módulo de Notificaciones se eliminó por completo. La Apariencia
 * ya solo ofrece un único tema fijo (Azul original / SIGAL): no hay
 * selección de tema oscuro ni claro, así que aquí solo se aplica ese
 * tema al cargar la pantalla.
 */
public class AjustesController {

    private final UsuarioDAO usuarioDAO = new UsuarioDAO();

    /** Referencia al menú, para leer los datos reales de la sesión (nombre, rol, correo, hora de acceso). */
    private MenuController menuController;

    // ---- Perfil de usuario ----
    @FXML private Label lblUsuario;
    @FXML private Label lblRol;
    @FXML private Label lblCorreo;
    @FXML private Label lblUltimoAcceso;
    @FXML private Label lblAvatarIcono;
    @FXML private ImageView imgAvatarAjustes;

    // ---- Apariencia (tema único) ----
    @FXML private VBox rootAjustes;
    @FXML private VBox cardTemaAzul;

    @FXML
    public void initialize() {
        // El tema se aplica hasta que la pantalla ya está dentro de la
        // ventana de SIGAL (antes de eso, getScene() todavía es null).
        rootAjustes.sceneProperty().addListener((obs, escenaVieja, escenaNueva) -> {
            if (escenaNueva != null) {
                ThemeManager.setTema(ThemeManager.Tema.AZUL_ORIGINAL);
                ThemeManager.apply(escenaNueva);
            }
        });
    }

    /**
     * Recibe la referencia del menú (llamada desde MenuController.cargarModulo)
     * y con ella llena la tarjeta "Perfil de usuario" con los datos reales
     * de la sesión: usuario, rol, correo y hora en la que inició sesión.
     */
    public void setMenuController(MenuController menuController) {
        this.menuController = menuController;
        cargarPerfilUsuario();
    }

    private void cargarPerfilUsuario() {
        if (menuController == null) {
            return;
        }
        lblUsuario.setText(menuController.getUsuarioActual());
        lblRol.setText(menuController.getRolActual());
        lblCorreo.setText(menuController.getCorreoActual());
        lblUltimoAcceso.setText(menuController.getHoraAccesoTexto());

        Usuario usuario = usuarioDAO.obtenerPorId(menuController.getIdUsuarioActual());
        AvatarUtil.aplicar(imgAvatarAjustes, lblAvatarIcono, usuario != null ? usuario.getFotoPerfil() : null);
    }

}